# Space Invaders Local (Android WebView)

Questa versione gira **offline** perché carica `index.html` da:
`file:///android_asset/www/index.html`

## Build APK (serve un PC con Android Studio)
1. Apri questo progetto in Android Studio
2. Build → Build APK(s)

> Da smartphone non puoi compilare un APK classico: qui trovi il progetto pronto.
